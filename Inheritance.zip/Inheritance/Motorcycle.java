class Motorcycle extends Vehicle {
    boolean hasSideCar;

    public Motorcycle(String model, int year, double price, boolean hasSideCar) {
        super(model, year, price);
        this.hasSideCar = hasSideCar;
    }

    public boolean hasSideCar() {
        return hasSideCar;
    }

    public String toString() {
        return "Motorcycle{" +
                "model='" + model + '\'' +
                ", year=" + year +
                ", price=" + price +
                ", hasSideCar=" + hasSideCar +
                '}';
    }
}