class Car extends Vehicle {
    int numberOfDoors;

    public Car(String model, int year, double price, int numberOfDoors) {
        super(model, year, price);
        this.numberOfDoors = numberOfDoors;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public String toString() {
        return "Car{" +
                "model='" + model + '\'' +
                ", year=" + year +
                ", price=" + price +
                ", numberOfDoors=" + numberOfDoors +
                '}';
    }
}
