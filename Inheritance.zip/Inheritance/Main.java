public class Main {
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle("Generic Vehicle", 2022, 20000.00);
        Car car = new Car("Toyota Camry", 2020, 30000.00, 4);
        Motorcycle motorcycle = new Motorcycle("Harley Davidson", 2019, 25000.00, true);

        System.out.println("Vehicle Details:");
        System.out.println(vehicle);
        System.out.println();

        System.out.println("Car Details:");
        System.out.println(car);
        System.out.println();

        System.out.println("Motorcycle Details:");
        System.out.println(motorcycle);
    }
}